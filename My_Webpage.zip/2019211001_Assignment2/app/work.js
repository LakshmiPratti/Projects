<!-- SCROLLIG TO TOP OF THE PAGE -->

function topFunction() {
document.body.scrollTop = 0; 
document.documentElement.scrollTop = 0; 
}
var mybutton = document.getElementById("myBtn");

<!-- CHANGE THE BACKGROUDN IMAGE IN INDEX FILE -->
$(document).ready(function(){
        var imageUrl = "https://cdn.glitch.com/6b3eba22-8c4d-498a-aa64-0e9f62ead282%2Fbuilding-your-product-photography-studio-on-a-budget1.jpg?v=1602085371154";
        $("body").css("background-image", "url(" + imageUrl + ")");
      
});

