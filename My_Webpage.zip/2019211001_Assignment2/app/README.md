#ASSIGNMENT 2

### ← Index.html

a) The navigation bar was created using HTML and CSS.
b) This is the first page of my website where I have used canvas for the main heading of the website, using sectioning of div and styling through css, setting the bacground-image using javascript and created a button which on clicking takes the user to top of the page.

### ← About.html

a) I made a box with specific dimensions and added my photo along side text using HTML and CSS

### ← Work.html

a) Using responsive layout of CSS, created a grid like structure with images, text can be inserted under each image, but I have used a common paragraph for a row.

### ← Contact.html

a) Responsive form was created using CSS and HTML, and social icons were added with links to my accounts.

### ← deco.css

CSS files added styling to my webpage, from giving dimensions to different sections, to giving font-style, size, padding, text-color etc.

### ← work.js

To add interactivity and make users comfortable to scroll up, a scroll up button was added.

### ← assets

Contains images I used in this project.

### ← link of project in glitch:
https://glitch.com/~lakshwebpage
### ← url of hosting at web.iiit.ac.in:
https://web.iiit.ac.in/~lakshmi.pratti/
