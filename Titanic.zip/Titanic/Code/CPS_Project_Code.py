#! usr/bin/python3

#Created By: Subhalakshmi Kandavel, Lakshmi Deepita Pratti, Mohit Tandon

import pandas as pd
import tkinter as tk
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

                     # Function for counting number of deaths #
def fun(values):
    ctr = 0
    for i in values:
        if i == 'No':
            ctr = ctr + 1
    return ctr


                  # Function for counting number of deaths per 100 #
def fun2(values):
    ctr = 0
    for i in values:
        if i == 'No':
            ctr = ctr + 1
    return round((100*ctr)/len(values))


df = pd.read_csv('titanicsurvival.csv')  
df_copy = df.copy(deep=True)                  # This will have original values

                  # Modifying the dataframe based on given information #
df['Class'] = df['Class'].replace({0:'Other', 1:'I',2:'II', 3:'III'})
df['Age'] = df['Age'].replace({0:'Child', 1:'Adult'})
df['Sex'] = df['Sex'].replace({0:'Female', 1:'Male'})
df['Survive'] = df['Survive'].replace({0:'No', 1:'Yes'})

titles = ["Male","Female","Both"]


                                 # By Economic Status and Sex #

print("\n\n********************** By Economic Status and Sex **********************")
print("\nPopulation Exposed to Risk| Number of Deaths | Deaths per 100 Exposed to Risk|\n")

                                 # Population Exposed to Risk#
tab_df1 = pd.pivot_table(df, index=["Class"], values='Survive', columns="Sex",
                         margins=True, margins_name='Both', fill_value=0,
                         aggfunc='count')
tab_df1 = tab_df1.reindex(columns = titles)

                                 #Number of deaths#
tab_df2 = pd.pivot_table(df, index=["Class"], values='Survive', columns="Sex",
                         margins=True, margins_name='Both', fill_value=0,
                         aggfunc=fun)
tab_df2 = tab_df2.reindex(columns = titles)


                              # Deaths per 100 Exposed to Risk
tab_df3 = pd.pivot_table(df, index=["Class"], values='Survive', columns="Sex",
                         margins=True, margins_name='Both', fill_value=0,
                         aggfunc=fun2)
tab_df3 = tab_df3.reindex(columns = titles)


pdList = [tab_df1, tab_df2, tab_df3]
new_df = pd.concat(pdList, axis=1)
print(new_df)
                                    
                                    #By Economic Status and Age#
print("\n\n********************** By Economic Status and Age **********************")
print("\nPopulation Exposed to Risk| Number of Deaths | Deaths per 100 Exposed to Risk|\n")

                                 # Population Exposed to Risk
tab_df4 = pd.pivot_table(df, index=["Class"], values='Survive', columns="Age",
                      margins=True, margins_name='Both', fill_value=0,
                         aggfunc='count')

                                      # Number of Deaths
tab_df5 = pd.pivot_table(df, index=["Class"], values='Survive', columns="Age",
                         margins=True, margins_name='Both', fill_value=0,
                         aggfunc=fun)

                             # Deaths per 100 Exposed to Risk
tab_df6 = pd.pivot_table(df, index=["Class"], values='Survive', columns="Age",
                         margins=True, margins_name='Both', fill_value=0,
                         aggfunc=fun2)

pdList = [tab_df4,tab_df5,tab_df6]
new_df = pd.concat(pdList, axis=1)
print(new_df)

                     # Visualization of the dataframe using matplotlib in GUI 
root= tk.Tk()
root.title('Titanic Unusual Episode')
useGrid = False
if useGrid:
    dpi_val = 70
else:
    dpi_val = 50

                          #BAR GRAPH#
figure1 = plt.Figure(figsize=(5,5),dpi=dpi_val)
ax1 = figure1.add_subplot(111)
bar1 = FigureCanvasTkAgg(figure1, root)
if useGrid:
    bar1.get_tk_widget().grid(row=0, column=0)
else:
    bar1.get_tk_widget().pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

tab_df1.plot(kind='bar', legend=True, ax=ax1, stacked=False)
ax1.set_title('Population Exposed To Risk')
                            
                            #AREA GRAPH#
figure2 = plt.Figure(figsize=(5,5), dpi=dpi_val)
ax2 = figure2.add_subplot(111)
line2 = FigureCanvasTkAgg(figure2, root)
if useGrid:
    line2.get_tk_widget().grid(row=0, column=1)
else:
    line2.get_tk_widget().pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
tab_df2.plot(kind='area', legend=True, ax=ax2, fontsize=10)
ax2.set_title('Number of Deaths w.r.t Sex')

                          #BAR GRAPH
figure3 = plt.Figure(figsize=(5,5), dpi=dpi_val)
ax3 = figure3.add_subplot(111)
box = FigureCanvasTkAgg(figure3, root)
if useGrid:
    box.get_tk_widget().grid(row=0, column=2)
else:
    box.get_tk_widget().pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
tab_df3.drop(['Both'], axis=1).plot(kind = 'bar', stacked=False, legend = True,ax = ax3)
ax3.set_title("Deaths per 100 in population w.r.t Sex")

                           #PIE CHART
figure4 = plt.Figure(figsize=(5,5), dpi=dpi_val)
ax4 = figure4.add_subplot(111)
pie = FigureCanvasTkAgg(figure4, root)
if useGrid:
    pie.get_tk_widget().grid(row=2, column=0)
else:
    pie.get_tk_widget().pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
df.groupby(['Class','Survive']).size().plot(kind='pie', fontsize = 10,
                                            title="% Survial/Death with respect to Economic status",
                                            autopct='%1.1f%%', ax=ax4)
ax4.set_title('% Survial/Death with respect to Economic status')

                            #Kernel Density Estimation
figure5 = plt.Figure(figsize=(5,5), dpi=dpi_val)
ax5 = figure5.add_subplot(111)
kde = FigureCanvasTkAgg(figure5, root)
if useGrid:
    kde.get_tk_widget().grid(row=2, column=1)
else:    
    kde.get_tk_widget().pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
tab_df5.plot(kind = 'kde', legend = True, ax=ax5, fontsize = 10, subplots = True, title='Number Of Deaths wrt Age')

                            #HORIZONTAL BAR GRAPH
figure6 = plt.Figure(figsize=(5,5), dpi=dpi_val)
ax6 = figure6.add_subplot(111)
barh = FigureCanvasTkAgg(figure6, root)
if useGrid:
    barh.get_tk_widget().grid(row=2, column=2)
else:
    barh.get_tk_widget().pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
tab_df6.drop(['Both'],axis=1).plot(kind = 'barh', legend = True, ax=ax6, 
                                   fontsize = 10, stacked = False, figsize=(10,10))
ax6.set_title('Deaths per 100 in a population wrt Age')

root.mainloop()
