#Created by: Lakshmi Deepita Pratti
#Roll no: 2019211001
#Date: 14th-feb-2020

from googlesearch import search
from requests_html import HTMLSession
from collections import Counter
import csv
import sys

if len(sys.argv) < 2:
    print("usage: python scrap.py \"search term(s)\" \neg: python3 scrap.py data science")
    sys.exit()

"""
************** Google Search **************
"""
query = str(" ".join(sys.argv[1:]))
print("Searching \"", query, "\"")
my_results_list = {}
for i in search(query, tld='com', lang='en', num=10, start=0, stop=10, pause=2.0):  # stop -- number of links (10)
    my_results_list.update({i: ["", 1]})  # Dictionary with format: {link: [title, occurrence]}

"""
************** Parsing the results **************
"""
session = HTMLSession()

for result in my_results_list:
    r = session.get(result)
    my_results_list[result][0] = r.html.find('title', first=True).text  # updating the result for the search result
    unique_links = Counter([link for link in r.html.absolute_links if link in my_results_list])
    for link in unique_links:
        my_results_list[link][1] += 1  # updating occurrence for the each search result based on links found on parsing

"""
************** Output to CSV **************
"""
with open('output.csv', 'w', newline='') as csvfile:
    wf = csv.writer(csvfile, delimiter=',')
    for result in my_results_list:
        wf.writerow([my_results_list[result][0], result, my_results_list[result][1]])

print(my_results_list)
