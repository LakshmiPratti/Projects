#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Apr 21 20:52:44 2020

@author: mohit
"""

import pandas as pd
import matplotlib.pyplot as plt

#enter the filename you want to plot

sir = pd.read_csv("filename.dat",sep=" ",header=None,names=["t","S","I","R"],index_col=False)

plt.style.use("ggplot")

s = plt.plot("t","S","",data=sir,color="yellow",linewidth=2)
i = plt.plot("t","I","",data=sir,color="red",linewidth=2)
r = plt.plot("t","R","",data=sir,color="green",linewidth=2)
plt.xlabel("Time",fontweight="bold")
plt.ylabel("Number",fontweight="bold")
legend = plt.legend(title="Population",loc=5,bbox_to_anchor=(1,0.5))
f = legend.get_frame()
f.set_facecolor("white")
f.set_linewidth(0)
